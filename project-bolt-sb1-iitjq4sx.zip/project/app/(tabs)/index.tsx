import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Wallet, Send, QrCode } from 'lucide-react-native';

export default function WalletScreen() {
  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://images.unsplash.com/photo-1635322966219-b75ed372eb01?q=80&w=1920&auto=format&fit=crop' }}
        style={StyleSheet.absoluteFill}
        blurRadius={20}
      />
      <LinearGradient
        colors={['rgba(0,0,0,0.7)', 'rgba(0,0,0,0.9)']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.content}>
        <View style={styles.header}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1635322966219-b75ed372eb01?q=80&w=400&auto=format&fit=crop' }}
            style={styles.avatar}
          />
          <Text style={styles.title}>Samus Oran Wallet</Text>
        </View>

        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>Total Balance</Text>
          <Text style={styles.balanceAmount}>$12,345.67</Text>
          <Text style={styles.solanaBalance}>123.45 SOL</Text>
          
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.actionButton}>
              <Send color="#00f6ff" size={24} />
              <Text style={styles.actionButtonText}>Send</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Wallet color="#00f6ff" size={24} />
              <Text style={styles.actionButtonText}>Receive</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <QrCode color="#00f6ff" size={24} />
              <Text style={styles.actionButtonText}>Scan</Text>
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Tokens</Text>
        {['SOL', 'USDC', 'RAY', 'SRM'].map((token) => (
          <View key={token} style={styles.tokenCard}>
            <View style={styles.tokenInfo}>
              <Text style={styles.tokenName}>{token}</Text>
              <Text style={styles.tokenBalance}>1,234.56</Text>
            </View>
            <Text style={styles.tokenValue}>$1,234.56</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 10,
    borderWidth: 2,
    borderColor: '#00f6ff',
  },
  title: {
    fontFamily: 'Rajdhani_700Bold',
    fontSize: 24,
    color: '#fff',
    textAlign: 'center',
  },
  balanceCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 30,
  },
  balanceLabel: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 16,
    color: '#94a3b8',
    marginBottom: 5,
  },
  balanceAmount: {
    fontFamily: 'Rajdhani_700Bold',
    fontSize: 36,
    color: '#fff',
  },
  solanaBalance: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 18,
    color: '#00f6ff',
    marginBottom: 20,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  actionButton: {
    alignItems: 'center',
  },
  actionButtonText: {
    fontFamily: 'Rajdhani_600SemiBold',
    color: '#fff',
    marginTop: 5,
  },
  sectionTitle: {
    fontFamily: 'Rajdhani_700Bold',
    fontSize: 20,
    color: '#fff',
    marginBottom: 15,
  },
  tokenCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 15,
    padding: 15,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  tokenInfo: {
    flex: 1,
  },
  tokenName: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 18,
    color: '#fff',
  },
  tokenBalance: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 14,
    color: '#94a3b8',
  },
  tokenValue: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 18,
    color: '#00f6ff',
  },
});