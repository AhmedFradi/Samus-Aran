import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { TrendingUp, TrendingDown } from 'lucide-react-native';

export default function MarketsScreen() {
  const markets = [
    { name: 'SOL/USD', price: '123.45', change: '+5.67%', trending: 'up' },
    { name: 'RAY/USD', price: '3.45', change: '-2.31%', trending: 'down' },
    { name: 'SRM/USD', price: '0.89', change: '+1.23%', trending: 'up' },
    { name: 'BONK/USD', price: '0.000034', change: '+12.34%', trending: 'up' },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#000', '#001a2c']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Markets</Text>
        
        {markets.map((market) => (
          <View key={market.name} style={styles.marketCard}>
            <View style={styles.marketInfo}>
              <Text style={styles.marketName}>{market.name}</Text>
              <Text style={styles.marketPrice}>${market.price}</Text>
            </View>
            <View style={styles.marketChange}>
              {market.trending === 'up' ? (
                <TrendingUp color="#00f6ff" size={20} />
              ) : (
                <TrendingDown color="#ef4444" size={20} />
              )}
              <Text style={[
                styles.changeText,
                { color: market.trending === 'up' ? '#00f6ff' : '#ef4444' }
              ]}>
                {market.change}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  title: {
    fontFamily: 'Rajdhani_700Bold',
    fontSize: 32,
    color: '#fff',
    marginBottom: 20,
  },
  marketCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  marketInfo: {
    flex: 1,
  },
  marketName: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 20,
    color: '#fff',
    marginBottom: 5,
  },
  marketPrice: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 16,
    color: '#94a3b8',
  },
  marketChange: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  changeText: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 16,
    marginLeft: 5,
  },
});