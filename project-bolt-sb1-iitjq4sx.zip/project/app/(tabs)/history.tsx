import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react-native';

export default function HistoryScreen() {
  const transactions = [
    { type: 'send', amount: '10.5 SOL', value: '$1,234.56', date: '2024-02-20 14:30' },
    { type: 'receive', amount: '100 USDC', value: '$100.00', date: '2024-02-19 09:15' },
    { type: 'send', amount: '5.2 SOL', value: '$612.34', date: '2024-02-18 16:45' },
    { type: 'receive', amount: '50 RAY', value: '$172.50', date: '2024-02-17 11:20' },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#000', '#001a2c']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Transaction History</Text>
        
        {transactions.map((tx, index) => (
          <View key={index} style={styles.txCard}>
            <View style={styles.txIcon}>
              {tx.type === 'send' ? (
                <ArrowUpRight color="#ef4444" size={24} />
              ) : (
                <ArrowDownLeft color="#00f6ff" size={24} />
              )}
            </View>
            <View style={styles.txInfo}>
              <Text style={styles.txType}>
                {tx.type === 'send' ? 'Sent' : 'Received'}
              </Text>
              <Text style={styles.txDate}>{tx.date}</Text>
            </View>
            <View style={styles.txAmount}>
              <Text style={[
                styles.amount,
                { color: tx.type === 'send' ? '#ef4444' : '#00f6ff' }
              ]}>
                {tx.type === 'send' ? '-' : '+'}{tx.amount}
              </Text>
              <Text style={styles.value}>{tx.value}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  title: {
    fontFamily: 'Rajdhani_700Bold',
    fontSize: 32,
    color: '#fff',
    marginBottom: 20,
  },
  txCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  txIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  txInfo: {
    flex: 1,
  },
  txType: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 18,
    color: '#fff',
  },
  txDate: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 14,
    color: '#94a3b8',
  },
  txAmount: {
    alignItems: 'flex-end',
  },
  amount: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 18,
  },
  value: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 14,
    color: '#94a3b8',
  },
});