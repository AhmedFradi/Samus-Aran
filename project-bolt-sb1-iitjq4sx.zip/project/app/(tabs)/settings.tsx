import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Shield, Bell, Moon, CircleHelp as HelpCircle, ExternalLink } from 'lucide-react-native';

export default function SettingsScreen() {
  const settingsItems = [
    { icon: Shield, title: 'Security', subtitle: 'Manage security settings' },
    { icon: Bell, title: 'Notifications', subtitle: 'Configure alerts' },
    { icon: Moon, title: 'Appearance', subtitle: 'Customize your experience' },
    { icon: HelpCircle, title: 'Help & Support', subtitle: 'Get assistance' },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#000', '#001a2c']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Settings</Text>
        
        {settingsItems.map((item, index) => (
          <TouchableOpacity key={index} style={styles.settingCard}>
            <View style={styles.settingIcon}>
              <item.icon color="#00f6ff" size={24} />
            </View>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>{item.title}</Text>
              <Text style={styles.settingSubtitle}>{item.subtitle}</Text>
            </View>
            <ExternalLink color="#64748b" size={20} />
          </TouchableOpacity>
        ))}

        <View style={styles.footer}>
          <Text style={styles.version}>Version 1.0.0</Text>
          <Text style={styles.copyright}>© 2024 Samus Oran Wallet</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  title: {
    fontFamily: 'Rajdhani_700Bold',
    fontSize: 32,
    color: '#fff',
    marginBottom: 20,
  },
  settingCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  settingInfo: {
    flex: 1,
  },
  settingTitle: {
    fontFamily: 'Rajdhani_600SemiBold',
    fontSize: 18,
    color: '#fff',
  },
  settingSubtitle: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 14,
    color: '#94a3b8',
  },
  footer: {
    marginTop: 40,
    marginBottom: 20,
    alignItems: 'center',
  },
  version: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 14,
    color: '#64748b',
  },
  copyright: {
    fontFamily: 'Rajdhani_400Regular',
    fontSize: 12,
    color: '#64748b',
    marginTop: 5,
  },
});